package com.phanthony.instantrecipe.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatButton
import androidx.fragment.app.Fragment
import androidx.lifecycle.AndroidViewModel
import com.phanthony.instantrecipe.R

class FindRecipeFragment: Fragment() {

    var image: Bitmap? = null
    lateinit var viewModel: AndroidViewModel
    private val RESULT_LOAD_IMAGE = 1

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.find_recipes_fragment,container,false)

        viewModel = activity!!.run {
            ViewModelProviders
        }

        val uploadReceipt: AppCompatButton = view.findViewById(R.id.uploadReceiptButton)
        uploadReceipt.setOnClickListener {
            val i = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(i, RESULT_LOAD_IMAGE)
        }
        return view
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if(requestCode == RESULT_LOAD_IMAGE && resultCode == Activity.RESULT_OK && data != null){
            val selectedImage = data.data!!
            val filePathColumn = arrayOf(MediaStore.Images.Media.DATA)
            val cursor = context!!.contentResolver.query(selectedImage,filePathColumn,null, null, null)!!.apply {
                moveToFirst()
            }

            val columnIndex = cursor.getColumnIndex(filePathColumn[0])
            val picturePath = cursor.getString(columnIndex)
            cursor.close()

            image = BitmapFactory.decodeFile(picturePath)

        }
    }
}