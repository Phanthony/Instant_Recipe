package com.phanthony.instantrecipe.ui

import android.graphics.Bitmap
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.firebase.ml.vision.FirebaseVision
import com.google.firebase.ml.vision.common.FirebaseVisionImage
import com.google.firebase.ml.vision.text.FirebaseVisionText

class SelectPicFragment: Fragment() {

    val TAG = "TEXT_FOUND"

    var image: Bitmap? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        return super.onCreateView(inflater, container, savedInstanceState)
    }

    fun runTextRecognition(){
        val firebaseImage = FirebaseVisionImage.fromBitmap(image!!)
        val recognizer = FirebaseVision.getInstance()
            .onDeviceTextRecognizer
        recognizer.processImage(firebaseImage).addOnCompleteListener { result ->
            if(result.isSuccessful){
                processTextRecognitionResult(result.result!!)
            }
            else{

            }
        }

    }

    private fun processTextRecognitionResult(texts: FirebaseVisionText) {
        val blocks = texts.textBlocks
        if(blocks.isEmpty()){

        }
        else{
            for(i in 0 until blocks.size){
                val lines = blocks[i].lines
                for(j in 0 until lines.size){
                    val elements = lines[j].elements
                    for(k in 0 until elements.size){
                        Log.i(TAG, elements[k].text)
                    }
                }
            }
        }
    }
}