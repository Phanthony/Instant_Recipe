package Main

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel

class ViewModel(application: Application): AndroidViewModel(application) {

    private var selectedImage: Bitmap? = null

    fun setImage(image: Bitmap){
        selectedImage = image
    }

    fun getImage() : Bitmap{
        return selectedImage!!
    }
}